﻿namespace SafeNotes
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Register = new System.Windows.Forms.Button();
			this.txtUsername = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.lblUser = new System.Windows.Forms.Label();
			this.lblPass = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// Register (Tombol)
			// 
			this.Register.Location = new System.Drawing.Point(150, 150);
			this.Register.Name = "Register";
			this.Register.Size = new System.Drawing.Size(94, 29);
			this.Register.TabIndex = 2;
			this.Register.Text = "Register";
			this.Register.UseVisualStyleBackColor = true;
			this.Register.Click += new System.EventHandler(this.btnRegister_Click);
			// 
			// txtUsername (Input Username)
			// 
			this.txtUsername.Location = new System.Drawing.Point(150, 50);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new System.Drawing.Size(200, 27);
			this.txtUsername.TabIndex = 0;
			// 
			// txtPassword (Input Password)
			// 
			this.txtPassword.Location = new System.Drawing.Point(150, 100);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(200, 27);
			this.txtPassword.TabIndex = 1;
			this.txtPassword.UseSystemPasswordChar = true;
			// 
			// lblUser (Label Username)
			// 
			this.lblUser.AutoSize = true;
			this.lblUser.Location = new System.Drawing.Point(50, 53);
			this.lblUser.Name = "lblUser";
			this.lblUser.Size = new System.Drawing.Size(75, 20);
			this.lblUser.TabIndex = 3;
			this.lblUser.Text = "Username";
			// 
			// lblPass (Label Password)
			// 
			this.lblPass.AutoSize = true;
			this.lblPass.Location = new System.Drawing.Point(50, 103);
			this.lblPass.Name = "lblPass";
			this.lblPass.Size = new System.Drawing.Size(70, 20);
			this.lblPass.TabIndex = 4;
			this.lblPass.Text = "Password";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(450, 250);
			this.Controls.Add(this.lblPass);
			this.Controls.Add(this.lblUser);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.txtUsername);
			this.Controls.Add(this.Register);
			this.Name = "Form1";
			this.Text = "Form Register";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button Register;
		private System.Windows.Forms.TextBox txtUsername;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.Label lblUser;
		private System.Windows.Forms.Label lblPass;
	}
}