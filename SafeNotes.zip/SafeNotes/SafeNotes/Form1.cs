using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SafeNotes
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		// Pastikan nama fungsi ini SAMA dengan yang dibuat saat Anda double-click tombol
		private void btnRegister_Click(object sender, EventArgs e)
		{
			// 1. Ambil data dari TextBox
			string username = txtUsername.Text.Trim();
			string password = txtPassword.Text;

			// 2. Validasi Input
			if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
			{
				MessageBox.Show("Username dan Password tidak boleh kosong!");
				return;
			}

			if (password.Length < 8)
			{
				MessageBox.Show("Password minimal 8 karakter!");
				return;
			}

			// 3. Hash Password & Simpan
			// Pastikan class SecurityHelper sudah ada dan benar
			try
			{
				string hash = SecurityHelper.HashPassword(password);
				string salt = ""; // If you need a salt, obtain it from SecurityHelper or elsewhere as appropriate

				string connString = "Server=localhost;Database=safenotes_db;Uid=root;Pwd=;";
				using (MySqlConnection conn = new MySqlConnection(connString))
				{
					conn.Open();
					string query = "INSERT INTO users (username, password_hash, password_salt) VALUES (@user, @hash, @salt)";

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@user", username);
						cmd.Parameters.AddWithValue("@hash", hash);
						cmd.Parameters.AddWithValue("@salt", salt);

						cmd.ExecuteNonQuery();
					}
				}

				MessageBox.Show("Registrasi Berhasil! Silakan Login.");
				this.Close(); // Menutup form register
			}
			catch (Exception ex)
			{
				MessageBox.Show("Terjadi Error: " + ex.Message);
			}
		}
	}
}