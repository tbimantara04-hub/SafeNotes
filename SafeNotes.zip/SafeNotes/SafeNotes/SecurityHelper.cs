﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using BCrypt.Net; // Ditambahkan: untuk BCrypt hashing yang modern

public static class SecurityHelper
{
	// [Perbaikan Path]: Menggunakan folder AppData lokal untuk penyimpanan file kunci yang lebih baik
	private static readonly string AppDataDirectory = Path.Combine(
		Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
		"SafeNotesID");
	private static readonly string KeyFilePath = Path.Combine(AppDataDirectory, "master.key");

	// --- BAGIAN 1: DPAPI & MASTER KEY ---

	public static byte[] GetMasterKey()
	{
		if (File.Exists(KeyFilePath))
		{
			// Jika file ada, baca dan Unprotect (Decrypt DPAPI)
			try
			{
				byte[] protectedKey = File.ReadAllBytes(KeyFilePath);
				return ProtectedData.Unprotect(protectedKey, null, DataProtectionScope.CurrentUser);
			}
			catch (CryptographicException)
			{
				throw new Exception("Gagal mendekripsi Master Key. Kunci hanya bisa dibuka oleh user/komputer yang menyimpannya.");
			}
		}
		else
		{
			// Jika belum ada, buat direktori, kunci random 32 bytes, Protect, dan simpan
			Directory.CreateDirectory(AppDataDirectory); // Pastikan direktori ada

			byte[] newKey = new byte[32];
			RandomNumberGenerator.Fill(newKey);

			byte[] protectedKey = ProtectedData.Protect(newKey, null, DataProtectionScope.CurrentUser);
			File.WriteAllBytes(KeyFilePath, protectedKey);

			return newKey;
		}
	}

	// --- BAGIAN 2: AES-GCM ENCRYPTION ---

	// Mengembalikan (ciphertext, nonce, tag)
	public static (byte[] ciphertext, byte[] nonce, byte[] tag) EncryptNote(string plainText, byte[] masterKey)
	{
		// Tag size 16 bytes (128-bit)
		using (var aes = new AesGcm(masterKey, 16))
		{
			var nonce = new byte[12]; // 96-bit nonce
			RandomNumberGenerator.Fill(nonce);

			var plainBytes = Encoding.UTF8.GetBytes(plainText);
			var ciphertext = new byte[plainBytes.Length];
			var tag = new byte[16]; // 128-bit tag

			aes.Encrypt(nonce, plainBytes, ciphertext, tag);

			return (ciphertext, nonce, tag);
		}
	}

	public static string DecryptNote(byte[] ciphertext, byte[] nonce, byte[] tag, byte[] masterKey)
	{
		// Tag size 16 bytes (128-bit)
		using (var aes = new AesGcm(masterKey, 16))
		{
			var plainBytes = new byte[ciphertext.Length];

			// Akan melempar CryptographicException jika tag tidak valid (data rusak)
			aes.Decrypt(nonce, ciphertext, tag, plainBytes);

			return Encoding.UTF8.GetString(plainBytes);
		}
	}

	// --- BAGIAN 3: HASHING PASSWORD (Diperbaiki menggunakan BCrypt) ---

	/// <summary>
	/// Menghitung hash password menggunakan BCrypt yang otomatis menyertakan salt.
	/// </summary>
	/// <param name="password">Password plain text dari input user.</param>
	/// <returns>String hash yang sudah digabungkan dengan salt.</returns>
	public static string HashPassword(string password)
	{
		// Work factor 12 (default) adalah standar yang baik
		return BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
	}

	/// <summary>
	/// Memverifikasi password yang dimasukkan dengan hash yang tersimpan.
	/// </summary>
	/// <param name="enteredPassword">Password plain text yang dimasukkan user.</param>
	/// <param name="storedHash">Hash BCrypt yang tersimpan di database.</param>
	/// <returns>True jika cocok, False jika tidak.</returns>
	public static bool VerifyPassword(string enteredPassword, string storedHash)
	{
		return BCrypt.Net.BCrypt.Verify(enteredPassword, storedHash);
	}
}