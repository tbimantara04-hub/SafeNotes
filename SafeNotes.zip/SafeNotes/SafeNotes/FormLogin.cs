﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SafeNotes
{
	public partial class FormLogin : Form
	{
		public FormLogin()
		{
			InitializeComponent();
		}

		private void btnLogin_Click(object sender, EventArgs e)
		{
			// 1. Bersihkan Input (Trim spasi di username)
			string username = txtUsername.Text.Trim();
			string password = txtPassword.Text; // Password jangan di-trim (spasi bisa jadi bagian password)

			// 2. Validasi Sederhana: Cek kosong
			if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
			{
				MessageBox.Show("Harap isi Username dan Password!");
				return;
			}

			string connString = "Server=localhost;Database=safenotes_db;Uid=root;Pwd=;";

			using (MySqlConnection conn = new MySqlConnection(connString))
			{
				try
				{
					conn.Open();

					// Query ambil hash & salt berdasarkan username
					string query = "SELECT id, password_hash, password_salt FROM users WHERE username = @user";

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@user", username);

						using (MySqlDataReader reader = cmd.ExecuteReader())
						{
							if (reader.Read())
							{
								// User ditemukan, ambil data
								int dbId = reader.GetInt32("id");
								string dbHash = reader.GetString("password_hash");
								string dbSalt = reader.GetString("password_salt");

								// 3. Verifikasi Password menggunakan Helper
								bool isValid = SecurityHelper.VerifyPassword(password, dbHash);

								if (isValid)
								{
									MessageBox.Show("Login Berhasil!");

									// Masuk ke FormMain (Dashboard) membawa ID user
									FormMain mainForm = new FormMain(dbId);
									mainForm.Show();

									// Sembunyikan form login
									this.Hide();
								}
								else
								{
									// Password salah
									// Tampilkan pesan error yang aman
									MessageBox.Show("Username atau Password salah!");
								}
							}
							else
							{
								// Username tidak ditemukan
								// Disamakan pesannya agar aman (tidak membocorkan info user)
								MessageBox.Show("Username atau Password salah!");
							}
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error Database: " + ex.Message);
				}
			}
		}

		// Tombol Daftar (Membuka Form Register)
		private void btnGoToRegister_Click(object sender, EventArgs e)
		{
			// Membuka jendela registrasi
			Form1 registerForm = new Form1();
			registerForm.Show();
		}
	}
}