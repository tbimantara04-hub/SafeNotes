﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace SafeNotes
{
	// Asumsi: Anda memiliki FormMain.Designer.cs yang mendefinisikan kontrol-kontrol ini.
	public partial class FormMain : Form
	{
		private int _currentUserId;
		// Ganti 'your_password' dengan password MySQL root Anda yang sebenarnya jika ada
		private readonly string connString = "Server=localhost;Database=safenotes_db;Uid=root;Pwd=;";

		// Variabel untuk melacak ID catatan yang sedang diedit/dilihat. 0 = Catatan Baru.
		private int _selectedNoteId = 0;

		public FormMain()
		{
			InitializeComponent();
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			Logger.Log("Aplikasi utama dibuka.");
		}

		// Constructor saat runtime (dipanggil setelah Login)
		public FormMain(int userId) : this()
		{
			_currentUserId = userId;
			this.Text = "SafeNotes - Dashboard (User ID: " + _currentUserId + ")";
		}

		// ====================================================================
		// 1. EVENT UTAMA FORM
		// ====================================================================

		private void FormMain_Load(object sender, EventArgs e)
		{
			LoadNotes();
			dgvNotes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
			btnDelete.Enabled = false; // Nonaktifkan Hapus saat form dimuat
		}

		private void FormMain_FormClosed(object sender, FormClosedEventArgs e)
		{
			Application.Exit();
		}

		// ====================================================================
		// 2. FUNGSI LOAD DATA DARI DATABASE
		// ====================================================================

		private void LoadNotes()
		{
			using (MySqlConnection conn = new MySqlConnection(connString))
			{
				try
				{
					conn.Open();
					// Ambil semua kolom PENTING termasuk yang terenkripsi
					string query = "SELECT id, title, category, created_at, updated_at, encrypted_content, iv, auth_tag FROM notes WHERE user_id = @uid ORDER BY updated_at DESC";
					MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
					adapter.SelectCommand.Parameters.AddWithValue("@uid", _currentUserId);

					DataTable dt = new DataTable();
					adapter.Fill(dt);
					dgvNotes.DataSource = dt;

					// Atur Header dan Sembunyikan kolom teknis
					if (dgvNotes.Columns["title"] != null) dgvNotes.Columns["title"].HeaderText = "Judul";
					if (dgvNotes.Columns["category"] != null) dgvNotes.Columns["category"].HeaderText = "Kategori";
					if (dgvNotes.Columns["created_at"] != null) dgvNotes.Columns["created_at"].HeaderText = "Dibuat";
					if (dgvNotes.Columns["updated_at"] != null) dgvNotes.Columns["updated_at"].HeaderText = "Diperbarui";

					if (dgvNotes.Columns["encrypted_content"] != null) dgvNotes.Columns["encrypted_content"].Visible = false;
					if (dgvNotes.Columns["iv"] != null) dgvNotes.Columns["iv"].Visible = false;
					if (dgvNotes.Columns["auth_tag"] != null) dgvNotes.Columns["auth_tag"].Visible = false;
					if (dgvNotes.Columns["id"] != null) dgvNotes.Columns["id"].Visible = false;
				}
				catch (Exception ex)
				{
					MessageBox.Show("Gagal memuat data: " + ex.Message);
					Logger.Log($"Gagal memuat data untuk User ID {_currentUserId}: {ex.Message}");
				}
			}
		}

		// ====================================================================
		// 3. TOMBOL SIMPAN (INSERT / UPDATE)
		// ====================================================================

		private void btnSave_Click(object sender, EventArgs e)
		{
			// Asumsi: NoteModel memiliki properti Title, Content, dan Category
			var note = new NoteModel
			{
				Title = txtTitle.Text,
				Content = txtContent.Text,
				Category = cmbCategory.Text
			};

			// B. Validasi Data Annotation (Diasumsikan sudah benar)
			var context = new ValidationContext(note, null, null);
			var results = new List<ValidationResult>();
			bool isValid = Validator.TryValidateObject(note, context, results, true);

			if (!isValid)
			{
				string errors = "";
				foreach (var error in results) errors += "- " + error.ErrorMessage + "\n";
				MessageBox.Show(errors, "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			// C. Proses Enkripsi & Simpan/Update
			try
			{
				byte[] masterKey = SecurityHelper.GetMasterKey();

				// =============== TAMBAHAN 1: VALIDASI MASTER KEY ===============
				if (masterKey == null || masterKey.Length != 32) // Kunci AES 256-bit harus 32 byte
				{
					MessageBox.Show("Sistem gagal mendapatkan Master Key. Akses mungkin ditolak (DPAPI).", "Kesalahan Kritis Kunci", MessageBoxButtons.OK, MessageBoxIcon.Error);
					Logger.Log($"Error Kritis: User ID {_currentUserId} gagal mendapatkan Master Key (Kunci invalid/panjang {masterKey?.Length ?? 0}).");
					return;
				}
				// ==============================================================

				var (ciphertext, nonce, tag) = SecurityHelper.EncryptNote(note.Content, masterKey);

				// =============== TAMBAHAN 2: VALIDASI OUTPUT ENKRIPSI ===============
				if (ciphertext.Length == 0 || nonce.Length != 12 || tag.Length != 16)
				{
					MessageBox.Show("Proses enkripsi gagal menghasilkan data lengkap. Master Key mungkin salah/rusak.", "Kesalahan Kritis Enkripsi", MessageBoxButtons.OK, MessageBoxIcon.Error);
					Logger.Log($"Error Kritis: User ID {_currentUserId} gagal enkripsi (output kosong atau panjang salah).");
					return;
				}
				// ====================================================================

				// Inisiasi Koneksi Database
				using (MySqlConnection conn = new MySqlConnection(connString))
				{
					conn.Open();
					string query;

					if (_selectedNoteId == 0)
					{
						// LOGIKA INSERT (Catatan BARU)
						query = "INSERT INTO notes (user_id, title, category, encrypted_content, iv, auth_tag, created_at, updated_at) " +
								"VALUES (@uid, @title, @cat, @content, @iv, @tag, NOW(), NOW())";
					}
					else
					{
						// LOGIKA UPDATE (Mengedit Catatan Lama)
						query = "UPDATE notes SET title = @title, category = @cat, encrypted_content = @content, iv = @iv, auth_tag = @tag, updated_at = NOW() " +
								"WHERE id = @id AND user_id = @uid";
					}

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@uid", _currentUserId);
						cmd.Parameters.AddWithValue("@title", note.Title);
						cmd.Parameters.AddWithValue("@cat", note.Category);
						cmd.Parameters.AddWithValue("@content", ciphertext);
						cmd.Parameters.AddWithValue("@iv", nonce);
						cmd.Parameters.AddWithValue("@tag", tag);

						if (_selectedNoteId != 0)
						{
							cmd.Parameters.AddWithValue("@id", _selectedNoteId);
						}

						int rowsAffected = cmd.ExecuteNonQuery(); // Tangkap jumlah baris yang terpengaruh

						// =============== TAMBAHAN 3: KONFIRMASI EKSEKUSI DATABASE ===============
						if (rowsAffected == 0)
						{
							MessageBox.Show("Penyimpanan gagal. Database tidak terpengaruh. Pastikan User ID valid.", "Gagal Eksekusi DB", MessageBoxButtons.OK, MessageBoxIcon.Warning);
							Logger.Log($"Gagal Eksekusi DB: User ID {_currentUserId} mencoba {(_selectedNoteId == 0 ? "INSERT" : "UPDATE")} tetapi 0 baris terpengaruh.");
							return;
						}
						// ====================================================================
					}
				}

				MessageBox.Show("Catatan tersimpan aman (Terenkripsi)!");
				Logger.Log($"User ID {_currentUserId} {(_selectedNoteId == 0 ? "membuat" : "mengedit")} catatan: {note.Title}");

				// Reset UI setelah simpan/update
				txtTitle.Clear();
				txtContent.Clear();
				_selectedNoteId = 0; // RESET ID setelah operasi selesai
				btnDelete.Enabled = false;
				LoadNotes();
			}
			catch (Exception ex)
			{
				// Tangkap semua error database/runtime lainnya
				MessageBox.Show("Error saat menyimpan: " + ex.Message);
				Logger.Log($"Error saat menyimpan catatan User ID {_currentUserId}: {ex.Message}");
			}
		}
		// ====================================================================
		// 4. SAAT TABEL DIKLIK (DEKRIPSI & AMBIL DATA EDIT)
		// ====================================================================

		private void dgvNotes_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex < 0) return;

			try
			{
				// Ambil ID dari baris yang diklik
				int noteId = Convert.ToInt32(dgvNotes.Rows[e.RowIndex].Cells["id"].Value);
				_selectedNoteId = noteId; // Set ID catatan yang sedang dilihat
				btnDelete.Enabled = true; // Aktifkan tombol Hapus

				using (MySqlConnection conn = new MySqlConnection(connString))
				{
					conn.Open();

					// Ambil detail catatan, termasuk data enkripsi
					string query = "SELECT title, category, encrypted_content, iv, auth_tag FROM notes WHERE id = @id AND user_id = @uid";
					MySqlCommand cmd = new MySqlCommand(query, conn);
					cmd.Parameters.AddWithValue("@id", noteId);
					cmd.Parameters.AddWithValue("@uid", _currentUserId);

					using (MySqlDataReader reader = cmd.ExecuteReader())
					{
						if (reader.Read())
						{
							// Ambil data enkripsi (byte[])
							byte[] encryptedContent = (byte[])reader["encrypted_content"];
							byte[] iv = (byte[])reader["iv"];
							byte[] tag = (byte[])reader["auth_tag"];

							// Dekripsi menggunakan Master Key
							byte[] masterKey = SecurityHelper.GetMasterKey();
							string plainText = SecurityHelper.DecryptNote(encryptedContent, iv, tag, masterKey);

							// Tampilkan data ke kontrol input
							txtTitle.Text = reader["title"].ToString();
							cmbCategory.Text = reader["category"].ToString();
							txtContent.Text = plainText;

							Logger.Log($"User ID {_currentUserId} mendekripsi dan membuka catatan ID {noteId}.");
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Gagal membuka catatan: " + ex.Message);
				Logger.Log($"Gagal mendekripsi catatan User ID {_currentUserId}: {ex.Message}");
			}
		}

		// ====================================================================
		// 5. TOMBOL HAPUS (DELETE)
		// ====================================================================

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (_selectedNoteId == 0) return;

			var result = MessageBox.Show("Apakah Anda yakin ingin menghapus catatan ini?",
										 "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

			if (result == DialogResult.Yes)
			{
				try
				{
					using (MySqlConnection conn = new MySqlConnection(connString))
					{
						conn.Open();
						// Pastikan hanya catatan milik user ini yang terhapus
						string query = "DELETE FROM notes WHERE id = @id AND user_id = @uid";

						using (MySqlCommand cmd = new MySqlCommand(query, conn))
						{
							cmd.Parameters.AddWithValue("@id", _selectedNoteId);
							cmd.Parameters.AddWithValue("@uid", _currentUserId);

							cmd.ExecuteNonQuery();
						}
					}

					MessageBox.Show("Catatan berhasil dihapus.", "Sukses");
					Logger.Log($"User ID {_currentUserId} berhasil menghapus catatan ID {_selectedNoteId}.");

					// Reset UI setelah dihapus
					txtTitle.Clear();
					txtContent.Clear();
					_selectedNoteId = 0;
					btnDelete.Enabled = false;
					LoadNotes();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Error saat menghapus: " + ex.Message, "Error");
					Logger.Log($"Error saat menghapus catatan User ID {_currentUserId}: {ex.Message}");
				}
			}
		}

		// Event DGV yang tidak digunakan (disarankan menggunakan CellClick)
		private void dgvNotes_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			// Kosongkan atau hapus jika tidak digunakan
		}
	}
}