﻿using System;
using System.IO;

public static class Logger
{
	private static readonly string LogFilePath = Path.Combine(
		Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
		"SafeNotesID",
		"app_activity.log");

	public static void Log(string message)
	{
		try
		{
			// Pastikan direktori ada
			Directory.CreateDirectory(Path.GetDirectoryName(LogFilePath));

			string logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {message}";

			// Tambahkan baris log ke file
			File.AppendAllText(LogFilePath, logEntry + Environment.NewLine);
		}
		catch (Exception ex)
		{
			// Gagal menulis log, kita bisa mengabaikannya di sini atau mencatatnya di Console
			System.Diagnostics.Debug.WriteLine($"LOGGER FAILED: {ex.Message}");
		}
	}
}