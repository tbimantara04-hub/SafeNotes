﻿using System.ComponentModel.DataAnnotations;

public class NoteModel
{
	[Required(ErrorMessage = "Judul wajib diisi.")]
	[StringLength(100, ErrorMessage = "Judul maksimal 100 karakter.")]
	public string Title { get; set; } // [cite: 48]

	[Required(ErrorMessage = "Isi catatan wajib diisi.")]
	public string Content { get; set; } // [cite: 47]

	public string Category { get; set; }
}