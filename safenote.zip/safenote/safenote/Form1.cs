using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; // Untuk validasi
using System.Windows.Forms;
using MySql.Data.MySqlClient; // Pastikan library MySql.Data sudah diinstall
using safenote.Models;        // Memanggil folder Models

namespace safenote
{
	public partial class LoginForm : Form
	{
		// Connection String
		string connectionString = "server=localhost;user=root;database=safenotes_db;port=3306;password=;";

		public LoginForm()
		{
			InitializeComponent();
		}

		// Event saat tombol Login diklik
		private void btnLogin_Click(object sender, EventArgs e)
		{
			// 1. Ambil data dari TextBox
			var loginData = new LoginModel
			{
				Username = txtUsername.Text,
				Password = txtPassword.Text
			};

			// 2. Validasi Input
			var validationContext = new ValidationContext(loginData);
			var results = new List<ValidationResult>();

			if (!Validator.TryValidateObject(loginData, validationContext, results, true))
			{
				MessageBox.Show(results[0].ErrorMessage, "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			// 3. Cek ke Database
			try
			{
				using (MySqlConnection conn = new MySqlConnection(connectionString))
				{
					conn.Open();

					// UPDATE: Kita perlu mengambil 'id' juga untuk dikirim ke Dashboard
					string query = "SELECT id, password_hash, password_salt FROM users WHERE username = @user";

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@user", loginData.Username);

						using (MySqlDataReader reader = cmd.ExecuteReader())
						{
							if (reader.Read())
							{
								string storedHash = reader.GetString("password_hash");
								string storedSalt = reader.GetString("password_salt");

								// Ambil ID User dari database
								int userId = reader.GetInt32(reader.GetOrdinal("id"));

								// 4. Verifikasi Password
								bool isValid = SecurityHelper.VerifyPassword(loginData.Password, storedHash, storedSalt);

								if (isValid)
								{
									MessageBox.Show("Login Berhasil!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);

									// --- MASUK KE DASHBOARD ---

									// 1. Sembunyikan form login
									this.Hide();

									// 2. Buka Main Form (Dashboard) dan kirim userId
									MainForm mainForm = new MainForm(userId);
									mainForm.ShowDialog(); // Program akan berhenti di sini sampai Dashboard ditutup/logout

									// 3. Jika Dashboard ditutup (Logout), tampilkan form login lagi
									this.Show();
									txtPassword.Clear(); // Bersihkan password demi keamanan
								}
								else
								{
									MessageBox.Show("Password salah!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
								}
							}
							else
							{
								MessageBox.Show("Username tidak ditemukan.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Koneksi Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// Event saat tombol Register diklik
		private void btnRegister_Click(object sender, EventArgs e)
		{
			// Membuka Form Register
			FormRegister frm = new FormRegister();

			// Sembunyikan login sementara (opsional, agar rapi)
			this.Hide();

			frm.ShowDialog(); // Tunggu sampai user selesai register/tutup form

			// Tampilkan login lagi setelah form register ditutup
			this.Show();
		}
	}
}