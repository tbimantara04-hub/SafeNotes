﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using safenote.Models;
using System.Collections.Generic;

namespace safenote
{
	public partial class MainForm : Form
	{
		string connectionString = "server=localhost;user=root;database=safenotes_db;port=3306;password=;";
		private int currentUserId; // Menyimpan ID user yang sedang login

		// Constructor menerima ID User dari Form Login
		public MainForm(int userId)
		{
			InitializeComponent();
			this.currentUserId = userId;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			LoadNotes();
		}

		// 1. FUNGSI MENAMPILKAN DATA (READ)
		private void LoadNotes()
		{
			try
			{
				using (MySqlConnection conn = new MySqlConnection(connectionString))
				{
					conn.Open();
					// Kita hanya mengambil ID, Judul, Kategori, dan Waktu. 
					string query = "SELECT id, title, category, created_at FROM notes WHERE user_id = @uid ORDER BY created_at DESC";
					MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
					adapter.SelectCommand.Parameters.AddWithValue("@uid", currentUserId);

					DataTable dt = new DataTable();
					adapter.Fill(dt);
					dgvNotes.DataSource = dt;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Gagal memuat data: " + ex.Message);
			}
		}

		// 2. TOMBOL SIMPAN (CREATE + ENCRYPT)
		private void btnSave_Click(object sender, EventArgs e)
		{
			var note = new NoteModel
			{
				Title = txtTitle.Text,
				Category = cmbCategory.Text,
				Content = txtContent.Text
			};

			var context = new ValidationContext(note);
			var results = new List<ValidationResult>();
			if (!Validator.TryValidateObject(note, context, results, true))
			{
				MessageBox.Show(results[0].ErrorMessage, "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				return;
			}

			try
			{
				byte[] masterKey = SecurityHelper.GetMasterKey();
				var (cipherText, iv, tag) = SecurityHelper.EncryptNote(note.Content, masterKey);

				using (MySqlConnection conn = new MySqlConnection(connectionString))
				{
					conn.Open();
					string query = @"INSERT INTO notes (user_id, title, category, encrypted_content, iv, auth_tag) 
                                     VALUES (@uid, @title, @cat, @content, @iv, @tag)";

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@uid", currentUserId);
						cmd.Parameters.AddWithValue("@title", note.Title);
						cmd.Parameters.AddWithValue("@cat", note.Category);
						cmd.Parameters.AddWithValue("@content", cipherText);
						cmd.Parameters.AddWithValue("@iv", iv);
						cmd.Parameters.AddWithValue("@tag", tag);

						cmd.ExecuteNonQuery();
					}
				}

				MessageBox.Show("Catatan berhasil diamankan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
				ClearForm();
				LoadNotes();
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error saat menyimpan: " + ex.Message);
			}
		}

		// 3. KLIK TABEL UNTUK MELIHAT ISI (DECRYPT)
		private void dgvNotes_CellClick(object sender, DataGridViewCellEventArgs e)
		{
			if (e.RowIndex < 0) return;

			int noteId = Convert.ToInt32(dgvNotes.Rows[e.RowIndex].Cells["id"].Value);

			try
			{
				using (MySqlConnection conn = new MySqlConnection(connectionString))
				{
					conn.Open();
					string query = "SELECT title, category, encrypted_content, iv, auth_tag FROM notes WHERE id = @id";

					using (MySqlCommand cmd = new MySqlCommand(query, conn))
					{
						cmd.Parameters.AddWithValue("@id", noteId);
						using (MySqlDataReader reader = cmd.ExecuteReader())
						{
							if (reader.Read())
							{
								txtTitle.Text = reader.GetString("title");
								cmbCategory.Text = reader.GetString("category");

								byte[] cipherText = (byte[])reader["encrypted_content"];
								byte[] iv = (byte[])reader["iv"];
								byte[] tag = (byte[])reader["auth_tag"];

								byte[] masterKey = SecurityHelper.GetMasterKey();
								string plainText = SecurityHelper.DecryptNote(cipherText, iv, tag, masterKey);

								txtContent.Text = plainText;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Gagal membuka catatan: " + ex.Message);
			}
		}

		private void btnDelete_Click(object sender, EventArgs e)
		{
			if (dgvNotes.CurrentRow == null)
			{
				MessageBox.Show("Pilih catatan dulu!");
				return;
			}

			int noteId = Convert.ToInt32(dgvNotes.CurrentRow.Cells["id"].Value);

			if (MessageBox.Show("Yakin hapus?", "Konfirmasi", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				try
				{
					using (MySqlConnection conn = new MySqlConnection(connectionString))
					{
						conn.Open();
						string query = "DELETE FROM notes WHERE id = @id";
						using (MySqlCommand cmd = new MySqlCommand(query, conn))
						{
							cmd.Parameters.AddWithValue("@id", noteId);
							cmd.ExecuteNonQuery();
						}
					}
					ClearForm();
					LoadNotes();
				}
				catch (Exception ex)
				{
					MessageBox.Show("Gagal hapus: " + ex.Message);
				}
			}
		}

		private void btnLogout_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void ClearForm()
		{
			txtTitle.Clear();
			txtContent.Clear();
			cmbCategory.SelectedIndex = -1;
		}
	}
}