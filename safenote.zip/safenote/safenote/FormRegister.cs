﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations; // Untuk Validasi
using System.Windows.Forms;
using MySql.Data.MySqlClient; // Library Database
using safenote.Models;        // Folder Models

namespace safenote
{
    public partial class FormRegister : Form
    {
        // Connection String (Sesuaikan jika ada password)
        string connectionString = "server=localhost;user=root;database=safenotes_db;port=3306;password=;";

        public FormRegister()
        {
            InitializeComponent();
        }

        // 1. TOMBOL KEMBALI
        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            this.Close(); // Menutup form register, kembali ke login
        }

        // 2. TOMBOL DAFTAR SEKARANG
        private void btnSubmitRegister_Click(object sender, EventArgs e)
        {
            // A. Ambil data dari TextBox
            var registerData = new RegisterModel
            {
                Username = txtUserReg.Text,
                Password = txtPassReg.Text,
                ConfirmPassword = txtConfirmPass.Text
            };

            // B. Validasi Input Menggunakan Data Annotation (Sesuai Soal No 4)
            var validationContext = new ValidationContext(registerData);
            var results = new List<ValidationResult>();

            // Jika validasi gagal (misal: password kurang panjang / tidak ada huruf besar)
            if (!Validator.TryValidateObject(registerData, validationContext, results, true))
            {
                // Tampilkan pesan error pertama yang ditemukan
                MessageBox.Show(results[0].ErrorMessage, "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Berhenti, jangan lanjut ke database
            }

            // C. Simpan ke Database
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Cek dulu apakah username sudah ada?
                    string checkQuery = "SELECT COUNT(*) FROM users WHERE username = @user";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@user", registerData.Username);
                        long count = (long)checkCmd.ExecuteScalar();
                        if (count > 0)
                        {
                            MessageBox.Show("Username sudah terpakai, silakan pilih yang lain.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // D. Hashing Password + Salt (Sesuai Soal No 1.3)
                    var (hash, salt) = SecurityHelper.HashPassword(registerData.Password);

                    // E. Insert User Baru
                    string insertQuery = "INSERT INTO users (username, password_hash, password_salt) VALUES (@user, @hash, @salt)";
                    using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@user", registerData.Username);
                        cmd.Parameters.AddWithValue("@hash", hash);
                        cmd.Parameters.AddWithValue("@salt", salt);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Registrasi Berhasil! Silakan Login.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close(); // Tutup form register
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Terjadi Kesalahan Database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}