﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace safenote // Sesuaikan dengan namespace project Anda
{
	public static class SecurityHelper
	{
		// File path untuk menyimpan Master Key yang terproteksi DPAPI
		private static readonly string KeyFilePath = "master.key";

		// 1. GENERATE & PROTECT MASTER KEY (DPAPI)
		public static byte[] GetMasterKey()
		{
			if (File.Exists(KeyFilePath))
			{
				// Jika file ada, baca dan dekripsi (Unprotect)
				byte[] protectedKey = File.ReadAllBytes(KeyFilePath);
				try
				{
					return ProtectedData.Unprotect(protectedKey, null, DataProtectionScope.CurrentUser);
				}
				catch
				{
					// Handle jika key rusak atau beda user
					return CreateNewKey();
				}
			}
			else
			{
				return CreateNewKey();
			}
		}

		private static byte[] CreateNewKey()
		{
			// Buat key baru (256-bit random)
			byte[] newKey = new byte[32];
			RandomNumberGenerator.Fill(newKey);

			// Enkripsi key dengan DPAPI dan simpan ke disk
			// Scope CurrentUser berarti hanya user Windows yang sedang login yang bisa membukanya
			byte[] protectedKey = ProtectedData.Protect(newKey, null, DataProtectionScope.CurrentUser);
			File.WriteAllBytes(KeyFilePath, protectedKey);

			return newKey;
		}

		// 2. PASSWORD HASHING (SHA-256 + SALT)
		public static (string hash, string salt) HashPassword(string password)
		{
			// Generate Salt
			byte[] saltBytes = new byte[16];
			RandomNumberGenerator.Fill(saltBytes);
			string salt = Convert.ToBase64String(saltBytes);

			// Gabung Password + Salt lalu Hash
			using (var sha256 = SHA256.Create())
			{
				byte[] combinedBytes = Encoding.UTF8.GetBytes(password + salt);
				byte[] hashBytes = sha256.ComputeHash(combinedBytes);
				string hash = Convert.ToBase64String(hashBytes);
				return (hash, salt);
			}
		}

		public static bool VerifyPassword(string enteredPassword, string storedHash, string storedSalt)
		{
			using (var sha256 = SHA256.Create())
			{
				byte[] combinedBytes = Encoding.UTF8.GetBytes(enteredPassword + storedSalt);
				byte[] hashBytes = sha256.ComputeHash(combinedBytes);
				string computedHash = Convert.ToBase64String(hashBytes);
				return computedHash == storedHash;
			}
		}

		// 3. ENKRIPSI CATATAN (AES-GCM)
		public static (byte[] cipherText, byte[] iv, byte[] tag) EncryptNote(string plainText, byte[] masterKey)
		{
			// GCM standard IV size = 12 bytes
			byte[] iv = new byte[12];
			RandomNumberGenerator.Fill(iv);

			byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
			byte[] cipherText = new byte[plainBytes.Length];

			// GCM standard tag size = 16 bytes
			byte[] tag = new byte[16];

			// Perbaikan: Menambahkan parameter tagSize (16) agar tidak obsolete/warning
			using (var aes = new AesGcm(masterKey, 16))
			{
				aes.Encrypt(iv, plainBytes, cipherText, tag);
			}

			return (cipherText, iv, tag);
		}

		// 4. DEKRIPSI CATATAN
		public static string DecryptNote(byte[] cipherText, byte[] iv, byte[] tag, byte[] masterKey)
		{
			byte[] decryptedBytes = new byte[cipherText.Length];

			// Perbaikan: Menambahkan parameter tagSize (16)
			using (var aes = new AesGcm(masterKey, 16))
			{
				try
				{
					aes.Decrypt(iv, cipherText, tag, decryptedBytes);
					return Encoding.UTF8.GetString(decryptedBytes);
				}
				catch (CryptographicException)
				{
					// Jika tag tidak valid atau data rusak
					return "Error: Gagal mendekripsi. Data mungkin rusak atau password salah.";
				}
			}
		}
	}
}