﻿namespace safenote
{
	partial class MainForm
	{
		private System.ComponentModel.IContainer components = null;

		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null)) components.Dispose();
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtTitle = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cmbCategory = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtContent = new System.Windows.Forms.TextBox();
			this.btnSave = new System.Windows.Forms.Button();
			this.dgvNotes = new System.Windows.Forms.DataGridView();
			this.btnDelete = new System.Windows.Forms.Button();
			this.btnLogout = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dgvNotes)).BeginInit();
			this.SuspendLayout();
			// 
			// label1 (Judul)
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(30, 30);
			this.label1.Name = "label1";
			this.label1.Text = "Judul Catatan";
			// 
			// txtTitle
			// 
			this.txtTitle.Location = new System.Drawing.Point(30, 55);
			this.txtTitle.Name = "txtTitle";
			this.txtTitle.Size = new System.Drawing.Size(250, 27);
			// 
			// label2 (Kategori)
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(30, 100);
			this.label2.Name = "label2";
			this.label2.Text = "Kategori";
			// 
			// cmbCategory
			// 
			this.cmbCategory.FormattingEnabled = true;
			this.cmbCategory.Location = new System.Drawing.Point(30, 125);
			this.cmbCategory.Name = "cmbCategory";
			this.cmbCategory.Size = new System.Drawing.Size(250, 28);
			this.cmbCategory.Items.AddRange(new object[] { "Pribadi", "Pekerjaan", "Password", "Keuangan" });
			// 
			// label3 (Isi)
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(30, 170);
			this.label3.Name = "label3";
			this.label3.Text = "Isi Catatan";
			// 
			// txtContent
			// 
			this.txtContent.Location = new System.Drawing.Point(30, 195);
			this.txtContent.Multiline = true;
			this.txtContent.Name = "txtContent";
			this.txtContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtContent.Size = new System.Drawing.Size(250, 200);
			// 
			// btnSave
			// 
			this.btnSave.Location = new System.Drawing.Point(30, 410);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(250, 40);
			this.btnSave.Text = "Simpan Catatan (Enkripsi)";
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// dgvNotes
			// 
			this.dgvNotes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvNotes.Location = new System.Drawing.Point(320, 55);
			this.dgvNotes.Name = "dgvNotes";
			this.dgvNotes.RowHeadersWidth = 51;
			this.dgvNotes.Size = new System.Drawing.Size(550, 340);
			this.dgvNotes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNotes_CellClick);
			// 
			// btnDelete
			// 
			this.btnDelete.Location = new System.Drawing.Point(320, 410);
			this.btnDelete.Name = "btnDelete";
			this.btnDelete.Size = new System.Drawing.Size(200, 40);
			this.btnDelete.Text = "Hapus Terpilih";
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			// 
			// btnLogout
			// 
			this.btnLogout.Location = new System.Drawing.Point(770, 410);
			this.btnLogout.Name = "btnLogout";
			this.btnLogout.Size = new System.Drawing.Size(100, 40);
			this.btnLogout.Text = "Logout";
			this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
			// 
			// MainForm
			// 
			this.ClientSize = new System.Drawing.Size(900, 500);
			this.Controls.Add(this.btnLogout);
			this.Controls.Add(this.btnDelete);
			this.Controls.Add(this.dgvNotes);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.txtContent);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.cmbCategory);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtTitle);
			this.Controls.Add(this.label1);
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SafeNotes - Dashboard";
			this.Load += new System.EventHandler(this.MainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.dgvNotes)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtTitle;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox cmbCategory;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtContent;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.DataGridView dgvNotes;
		private System.Windows.Forms.Button btnDelete;
		private System.Windows.Forms.Button btnLogout;
	}
}