﻿using System.ComponentModel.DataAnnotations;

namespace safenote.Models
{
	public class RegisterModel
	{
		[Required(ErrorMessage = "Username wajib diisi")]
		public string Username { get; set; }

		[Required(ErrorMessage = "Password wajib diisi")]
		[MinLength(8, ErrorMessage = "Password minimal 8 karakter")]
		// Regex: Harus ada Huruf Besar (A-Z), Huruf Kecil (a-z), dan Angka (\d)
		[RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$",
			ErrorMessage = "Password harus mengandung huruf besar, huruf kecil, dan angka.")]
		public string Password { get; set; }

		[Required(ErrorMessage = "Konfirmasi password wajib diisi")]
		[Compare("Password", ErrorMessage = "Password dan Konfirmasi tidak cocok")]
		public string ConfirmPassword { get; set; }
	}
}	