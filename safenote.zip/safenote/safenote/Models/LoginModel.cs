﻿using System.ComponentModel.DataAnnotations;

namespace safenote.Models
{
	public class LoginModel
	{
		[Required(ErrorMessage = "Username tidak boleh kosong")]
		public string Username { get; set; }

		[Required(ErrorMessage = "Password tidak boleh kosong")]
		public string Password { get; set; }
	}
}