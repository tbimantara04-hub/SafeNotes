﻿using System.ComponentModel.DataAnnotations;

namespace safenote.Models
{
	public class NoteModel
	{
		[Required(ErrorMessage = "Judul catatan harus diisi")]
		[StringLength(100, ErrorMessage = "Judul maksimal 100 karakter")]
		public string Title { get; set; }

		[Required(ErrorMessage = "Kategori harus dipilih")]
		public string Category { get; set; }

		[Required(ErrorMessage = "Isi catatan tidak boleh kosong")]
		public string Content { get; set; }
	}
}