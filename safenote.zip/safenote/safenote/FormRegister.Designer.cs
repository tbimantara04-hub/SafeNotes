﻿namespace safenote
{
	partial class FormRegister
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtUserReg = new System.Windows.Forms.TextBox();
			this.txtPassReg = new System.Windows.Forms.TextBox();
			this.txtConfirmPass = new System.Windows.Forms.TextBox();
			this.btnSubmitRegister = new System.Windows.Forms.Button();
			this.btnBackToLogin = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(50, 50);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "Username";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(50, 100);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(70, 20);
			this.label2.TabIndex = 1;
			this.label2.Text = "Password";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(50, 150);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(145, 20);
			this.label3.TabIndex = 2;
			this.label3.Text = "Konfirmasi Password";
			// 
			// txtUserReg
			// 
			this.txtUserReg.Location = new System.Drawing.Point(220, 47);
			this.txtUserReg.Name = "txtUserReg";
			this.txtUserReg.Size = new System.Drawing.Size(200, 27);
			this.txtUserReg.TabIndex = 3;
			// 
			// txtPassReg
			// 
			this.txtPassReg.Location = new System.Drawing.Point(220, 97);
			this.txtPassReg.Name = "txtPassReg";
			this.txtPassReg.PasswordChar = '*';
			this.txtPassReg.Size = new System.Drawing.Size(200, 27);
			this.txtPassReg.TabIndex = 4;
			// 
			// txtConfirmPass
			// 
			this.txtConfirmPass.Location = new System.Drawing.Point(220, 147);
			this.txtConfirmPass.Name = "txtConfirmPass";
			this.txtConfirmPass.PasswordChar = '*';
			this.txtConfirmPass.Size = new System.Drawing.Size(200, 27);
			this.txtConfirmPass.TabIndex = 5;
			// 
			// btnSubmitRegister
			// 
			this.btnSubmitRegister.Location = new System.Drawing.Point(220, 200);
			this.btnSubmitRegister.Name = "btnSubmitRegister";
			this.btnSubmitRegister.Size = new System.Drawing.Size(200, 35);
			this.btnSubmitRegister.TabIndex = 6;
			this.btnSubmitRegister.Text = "Daftar Sekarang";
			this.btnSubmitRegister.UseVisualStyleBackColor = true;
			this.btnSubmitRegister.Click += new System.EventHandler(this.btnSubmitRegister_Click);
			// 
			// btnBackToLogin
			// 
			this.btnBackToLogin.Location = new System.Drawing.Point(50, 200);
			this.btnBackToLogin.Name = "btnBackToLogin";
			this.btnBackToLogin.Size = new System.Drawing.Size(120, 35);
			this.btnBackToLogin.TabIndex = 7;
			this.btnBackToLogin.Text = "Kembali";
			this.btnBackToLogin.UseVisualStyleBackColor = true;
			this.btnBackToLogin.Click += new System.EventHandler(this.btnBackToLogin_Click);
			// 
			// FormRegister
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(500, 300);
			this.Controls.Add(this.btnBackToLogin);
			this.Controls.Add(this.btnSubmitRegister);
			this.Controls.Add(this.txtConfirmPass);
			this.Controls.Add(this.txtPassReg);
			this.Controls.Add(this.txtUserReg);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "FormRegister";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "SafeNotes - Registrasi";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtUserReg;
		private System.Windows.Forms.TextBox txtPassReg;
		private System.Windows.Forms.TextBox txtConfirmPass;
		private System.Windows.Forms.Button btnSubmitRegister;
		private System.Windows.Forms.Button btnBackToLogin;
	}
}